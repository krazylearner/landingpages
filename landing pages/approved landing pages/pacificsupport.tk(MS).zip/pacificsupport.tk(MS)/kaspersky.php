<?php include 'recorder.php';?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<!-- Mirrored from Comptek Solution .com/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 24 Sep 2015 09:41:36 GMT -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <meta name="description" content="Get online technical support and help for kaspersky issues and errors by certified technicians." />
<title>Online Expert Support For Kaspersky</title>
<link type="text/css" rel="stylesheet" href="css/main.css" media="screen"/>
<link rel="stylesheet" href="menu.css" type="text/css" media="screen" />
<script type="text/javascript" src="js/jquery.js"></script>

<!--End Navigation JavaScript Tag-->
<script type="text/javascript">
        jQuery(window).scroll(function () {
            var topmargin = 400;
                if (jQuery(window).scrollTop() > topmargin) {
                jQuery('#tfnaction').animate({ 'top': '-90px' }, 600);
            } else if (jQuery(window).scrollTop() < (topmargin - 20)) {
                jQuery('#tfnaction').stop(true).animate({ 'top': '96px' }, 500);
            }
        });
    </script>
  <script type="text/javascript">
// Popup window code
function newPopup(url) {
  popupWindow = window.open(
    url,'popUpWindow','height=500,width=500,left=10,top=10,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes')
}
</script>
</head>
<body>
<div id="header">
  <div class="header_outer_cntr">
    <div class="logoCntr float_L" style="width:180px;">



</div>
<div class="logoCntr float_L" style="width:180px;background:none;">

<a href="JavaScript:newPopup('https://tawk.to/24e81657d08ade8914615b8175d8e38db4e91562/popout/default/?$_tawk_popout=true&$_tawk_sk=56538851f60b7a928423b5ef&$_tawk_tk=33ade6004ae129696e93af35e3f0fc6c&v=452');"><img src="./pics/live-chat1.png" width="190" alt="live chat"></a>
</div>

<div class="nav_cntr_outer float_L" style="width:600px;">
      <ul id="nav">
        <li><a href="kaspersky.php">Home</a></li>
<li><a href="about_us.php" title="About Us">About us </a></li>
        <li><a href="#" title="services">Services</a>
          <ul>   
            <li><a>Support For Antivirus</a></li>
            <li><a>Support For PC</a></li>
            <li><a>Support For Browsers</a></li>
            <li><a>Support For Printers</a></li>
            <li><a>Support For Virus Definations</a></li>
          </ul>
        </li>
        <li><a href="client_testimonial.php" title="Testimonials">Clients testimonial</a></li>
        <li><a href="plan.php" title="Plans">Plan</a></li>
        <li><a href="contact_us.php" title="Contact Us">Contact us</a></li>
      </ul>
    </div>
    <div class="Flag_contr">
    <img src="pics/flage.png" alt="flags"  class="float_R"/> </div>
  </div>
</div>
<div class="wrapper">
<div class="tfnBox" id="tfnaction">
        <div class="centerCntr">
             <strong>Support For Kaspersky Call </strong>
        <span class="tfn_text">1-844-441-3440</span></div>
</div>
  <div class="banner_cntr float_L">
    <div id="slidebox">
     
      <div class="container">
        
        <div class="content">
          <div><img src="pics/Kaspersky.jpg"  alt="Comptek Solution" /></div>
        </div>
      </div>
    </div>
  </div>
<div>
 

  
       </div>
        <div><p>
       Disclaimer: Comptek Solution is an independent third party service provider for several brands. The service we offer is also available on the website of the brand owner. The services can be offered even if the product is on warranty or not. Use of names, trademarks is for reference only. We disclaim any ownership, right, affiliation or endorsement of or by any such third party products or brands.</p>
       </div>
    
       
  <div class="banner_btm_cntr">
    <div class="ask_a_ques_cntr" style="float:left; min-width:180px; padding-left:0px;"> <img src="pics/24-icon.png" alt="Live Tech Support"  class="float_L"/>
      <h3><a href="#">Live Tech<br />
        Support</a></h3>
    </div>
    <img src="pics/24_border.png" alt="border"  class="bordr" style="float:left;"/>
    <div class="ask_a_ques_cntr" style="float:left; padding:px"> <img src="pics/toll_Free.png" alt="Toll Free Number"  class="float_L"/>
      <h3>1-844-441-3440<br>Toll Free Number</h3>
    </div>
    <img src="pics/24_border.png" alt="border"  class="bordr" style="float:left;"/>
    <div class="ask_a_ques_cntr" style="float:left;"> <img src="pics/100_satisfiction.png" alt="Free Diagnosis"  class="float_L"/>
      <h3> No Fix No Pay <br> Free Diagnosis
      </h3>
    </div>
    <img src="pics/24_border.png" alt="border" class="bordr" style="float:left;"/>
    <div class="ask_a_ques_cntr" style="float:left;"> <img src="pics/certified_profesional.png" alt="Certified Professionals"  class="float_L"/>
     <h3>Certified<br>Proffesional</h3>
    </div>
  </div>
  
  
  <div class="Page_Maincontr">
    <div class="Page_Left_MainContr">
      <div class="Who_We_Are_MainContr">
        <h3 class="heading">Welcome to Comptek Solution</h3>
        <p>Comptek Solution is a leading online tech-support company which delivers short term as well long term computer support and assistance. We provides technical support services for all types of issues related to <a href="https://en.wikipedia.org/wiki/Antivirus_software">antivirus</a> updates,antivirus installation,antivirus virus definations,virus removal,Kaspersky errors ,Kaspersky general issues ,Kaspersky virus defination updates,Kaspersky renewal problems etc . 
          <br />
          We will fix any issue with your computer at your desired time, making sure all your data is safe and secure, you do not need to go anywhere, we will diagnose the issue and fix your computer on secured network saving you time and money. </p>
          <br><br>
          <h2>Our Help and Support services for Kaspersky® Antivirus includes:</h2>
          <br>
     
       
    <p>Setup & install Kaspersky antivirus in your computer</p>
    <p>Update or upgrade Kaspersky Product to latest version</p>
    <p>Uninstall or remove Kaspersky Product from your PC</p>
    <p>Scan your computer for viruses and other Malwares</p>
    <p>Neutralize or fix the threats detected by Kaspersky Antivirus</p>
    <p>Tune up your computer so that it runs at its optimal speed</p>
    <p>Configure Kaspersky settings for better security and protection of your PC</p>
    <p>Customize Kaspersky antivirus setting as per your requirements</p>
    
      <br>
        <a href="about_us.php" class="readmore"><img src="pics/view_more.png" alt="view more"  /></a> </div>
    </div>
    <div class="Page_Middle_Border"></div>
    <div class="Page_Right_MainContr">
      <h3 class="heading2">Services</h3>
      <div class="Our_Services_Maincontr">
        <div class="Our_Services_ImgContr"><img src="pics/1.png" alt="services" /></div>
        <div class="Our_services_COntnt_Contr">
          <h4>Support for PC</h4>
          <p>Our Support certified Techs use different tools to ensure optimal pc performance</p>
          <a href="#"><img src="pics/readmore.png" alt="readmore"   height="9" width="74"/></a> </div>
      </div>
      <div class="Our_Services_Maincontr">
        <div class="Our_Services_ImgContr"><img src="pics/1.png" alt="services" /></div>
        <div class="Our_services_COntnt_Contr">
          <h4>Antivirus Support</h4>
          <p>Security is an important issue nowadays whether it is online or offline world. If you don’t want to put your security at stake,</p>
          <a href="#"><img src="pics/readmore.png" alt="readmore"   height="9" width="74"/></a> </div>
      </div>
      <div class="Our_Services_Maincontr">
        <div class="Our_Services_ImgContr"><img src="pics/1.png" alt="services" /></div>
        <div class="Our_services_COntnt_Contr">
          <h4>Virus removal</h4>
          <p>Safety and security to data on your computer, complete peace of mind to you</p>
          <a href="#"><img src="pics/readmore.png" alt="readmore"   height="9" width="74"/></a> </div>
      </div>
      <div class="Our_Services_Maincontr">
        <div class="Our_Services_ImgContr"><img src="pics/1.png" alt="services" /></div>
        <div class="Our_services_COntnt_Contr">
          <h4>Unlimited Support</h4>
          <p>Unlimited support all year long with dedicated on call certified tech support experts. </p>
          <a href="#"><img src="pics/readmore.png" alt="readmore"   height="9" width="74"/></a> </div>
      </div>
      <div class="Our_Services_Maincontr">
        <div class="Our_Services_ImgContr"></div>
         </div>
    </div>
  </div>
</div>


<div class="Page_Bottom_MainContr">
  <!--strt_Page_Bottom_MainContr-->
  <div class="Page_Bottom_Contr">
     <cite>IF WE CAN'T FIX YOUR COMPUTER, YOU DON'T OWE US A DIME.</cite>
     
    <div class="image_Gallry_contr">
      <marquee behavior="" scrollamount="4" onmouseover="stop();" onmouseout="start();">
      </marquee>
    </div>
    
   
  
    
    <div class="FootrNav_Maincontr">
    
      <div class="float_L pc_solution_Cntr"> <span class="Quick_resolution">Comptek Solution</span>
       <h4> Toll Free: 1-844-441-3440</h4>
          <h4>Email: support@compteksolution.com </h4>
          <img src="pics/paypal.png" alt="payment" />
      </div>
       <div class="float_L pc_solution_Cntr"> <span class="Quick_resolution">We Support</span>
        <ul class="quick_ul_li_cntr">
         <li> <a href="#">Support For Antivirus</a></li>
          <li><a href="#">Support For Antivirus Update </a></li>
          <li><a href="#">Laptop Software Support</a></li>
           <li><a href="#">Support For Printer</a></li>
           <li><a href="#">Data Recovery</a></li>
        </ul>
      </div>
      <div class="float_L pc_solution_Cntr"> <span class="Quick_resolution"></span>
        <ul class="quick_ul_li_cntr">
         
         
         
          <li><a href="#">Printers Driver Update</a></li>
          <li><a href="#">Browser Support</a></li>
          <li><a href="#">Operating System Support</a></li>
          <li><a href="#">PC Tune Up </a></li>
          <li><a href="#">PC Optimization</a></li>
          
         
          
         </ul>
      </div>
      <div class="float_L pc_solution_Cntr"> <span class="Quick_resolution">Important Links</span>

        <ul class="quick_ul_li_cntr">
          
        <li><a href="index-2.php" title="Home">Home</a></li>
        <li><a href="about_us.php" title="About Us">About us</a></li>
        <li><a href="privacy_policy.php" title="Privacy POlicy">Privacy Policy</a></li>
        <li><a href="refund_policy.php" title="Refund Policy">Refund Policy</a></li>
        <li><a href="terms_of_use.php" title="Terms of Use">Terms of Use</a></li>
       
        <li><a href="contact_us.php" title="Contact Us">Contact us</a></li>
        </ul>
      </div>
    </div>
   
      
     
      
      
      
  </div>
  <!--strt_Page_Bottom_MainContr-->
</div>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-69752099-1', 'auto');
  ga('send', 'pageview');

</script>
<!-- Google Code for Visitor Stat Conversion Page -->
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="http://www.googleadservices.com/pagead/conversion/951392627/?label=Yy2UCJSfrVsQ87LUxQM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>

<!--Start of Tawk.to Script-->

<!--End of Tawk.to Script-->
<div style="background-color: #000; border: 1px solid #000; bottom: 0; color: #fff; font-size: 20px;  padding: 15px 0px; position: fixed; text-align: center; width: 100%; z-index: 5432;">
   <marquee behavior="" scrollamount="4" onmouseover="stop();" onmouseout="start();">
      <span id="popup1">Technical Experts Are Online Now Call Us  :</span> <a><span style="color:white;">+1-844-441-3440 (Toll Free)</span></a><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Free Diagnosis</span><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;No Fix No Pay</span><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;100 % Customer Satisfaction.</span>
      </marquee>
          
      </div>
      <div id="#chat">
      <!--Start of Tawk.to Script-->
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/563d9414b2ea3bb02546b27e/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<!--End of Tawk.to Script-->
 </div>
 
 <script>
(function(w,d,t,r,u){var f,n,i;w[u]=w[u]||[],f=function(){var o={ti:"5128764"};o.q=w[u],w[u]=new UET(o),w[u].push("pageLoad")},n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function(){var s=this.readyState;s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null)},i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)})(window,document,"script","//bat.bing.com/bat.js","uetq");</script>
<noscript><img src="//bat.bing.com/action/0?ti=5128764&Ver=2" height="0" width="0" style="display:none; visibility: hidden;" /></noscript>
 </body>
</html>