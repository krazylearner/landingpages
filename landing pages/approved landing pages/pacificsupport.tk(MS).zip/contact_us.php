<?php include 'recorder.php';?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<!-- Mirrored from Comptek Solution .com/contact_us by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 24 Sep 2015 09:42:53 GMT -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Contact Us</title>
<link type="text/css" rel="stylesheet" href="css/main.css" media="screen"/>
<link rel="stylesheet" href="menu.css" type="text/css" media="screen" />
<script type="text/javascript" src="js/jquery.js"></script>

<!--End Navigation JavaScript Tag-->
<script type="text/javascript">
        jQuery(window).scroll(function () {
            var topmargin = 400;
                if (jQuery(window).scrollTop() > topmargin) {
                jQuery('#tfnaction').animate({ 'top': '-90px' }, 600);
            } else if (jQuery(window).scrollTop() < (topmargin - 20)) {
                jQuery('#tfnaction').stop(true).animate({ 'top': '96px' }, 500);
            }
        });
    </script>
</head>
<body>
<div id="header">
  <div class="header_outer_cntr">
     <div class="logoCntr float_L" style="width:180px;">



</div>
   <div class="logoCntr float_L" style="width:180px;background:none;">

<a href="JavaScript:newPopup('https://tawk.to/24e81657d08ade8914615b8175d8e38db4e91562/popout/default/?$_tawk_popout=true&$_tawk_sk=56538851f60b7a928423b5ef&$_tawk_tk=33ade6004ae129696e93af35e3f0fc6c&v=452');"><img src="./pics/live-chat1.png" width="190" alt="live chat"></a>
</div>

<div class="nav_cntr_outer float_L" style="width:600px;">
      <ul id="nav">
        <li><a href="index-2.php">Home</a></li>
<li><a href="about_us.php" title="About Us">About us </a></li>
        <li><a href="#" title="services">Services</a>
          <ul>   
            <li><a>Support For Antivirus</a></li>
            <li><a>Support For PC</a></li>
            <li><a>Support For Browsers</a></li>
            <li><a>Support For Printers</a></li>
            <li><a>Support For Virus Definations</a></li>
          </ul>
        </li>
        <li><a href="client_testimonial.php" title="Testimonials">Clients testimonial</a></li>
        <li><a href="plan.php" title="Plans">Plan</a></li>
        <li><a href="contact_us.php" title="Contact Us">Contact us</a></li>
      </ul>
    </div>
    <div class="Flag_contr"><img src="pics/flage.png" alt="flags"  class="float_R"/> </div>
  </div>
</div>
<div class="wrapper">
<div class="tfnBox" id="tfnaction">
        <div class="centerCntr">
             <strong>Call for Expert Tech Support</strong>
        <span class="tfn_text">1-844-441-3440</span></div>
</div>
<br><br><br><br><br><br><br><br><br><br><br><br>
         <div class="Page_Maincontr">
        <div class="Page_Left_MainContr2">
        <div class="About_us_MainContr">
        
  <div class="Form_MainContr">
  
  
  
  <div class="Formcontr">
  <iframe src="https://docs.google.com/forms/d/1dJoOwPBUA4uUeQJpUcMWCoIWhQG9n-d8yP6KozgYsyI/viewform?embedded=true" width="600" height="800" frameborder="0" marginheight="0" marginwidth="0">Loading...</iframe>
  </div>
 
  </div>
        
        </div>
        
         
        </div>
        <div class="Page_Middle_Border"></div>
        <div class="Page_Right_MainContr2">
        <h3 class="heading2">Get in touch!</h3>
        <div class="Testimonial_Maincontr">
          <div class="Testimonial_contr">
 
   Comptek Solution LLC<br />
   A Delaware LImited Liability Company
   <h4> Toll Free: 1-844-441-3440</h4>
  <h4>Email: support@compteksolution.com </h4>
   Hour of Operation: 9 am to 5 pm CST daily except major holidays <br />
  



           
          </div>
                 
        </div>
        
        
        
        
        </div>
        
        </div>
        <div><p>
       Disclaimer: Comptek Solution is an independent third party service provider for several brands. The service we offer is also available on the website of the brand owner. The services can be offered even if the product is on warranty or not. Use of names, trademarks is for reference only. We disclaim any ownership, right, affiliation or endorsement of or by any such third party products or brands.</p>
       </div>
   
</div>



<div class="Page_Bottom_MainContr">
  <!--strt_Page_Bottom_MainContr-->
  <div class="Page_Bottom_Contr">
    <div class="image_Gallry_contr">
      <marquee behavior="" scrollamount="4" onmouseover="stop();" onmouseout="start();">
      
      </marquee>
    </div>
    
     
    
    
    
   <div class="FootrNav_Maincontr">
      <div class="float_L pc_solution_Cntr"> <span class="Quick_resolution">Comptek Solution</span>
     
          <h4> Toll Free: 1-844-441-3440</h4>
          <h4>Email: support@compteksolution.com </h4>
          <img src="pics/paypal.png" alt="payment" />
 <!-- (c) 2005, 2015. Authorize.Net is a registered trademark of CyberSource Corporation --> <div class="AuthorizeNetSeal"> <script type="text/javascript" language="javascript">var ANS_customer_id="d1a5e3a4-08ba-4cab-9e74-41c9d1d8a9a1";</script> <script type="text/javascript" language="javascript" src="../verify.authorize.net/anetseal/seal.js" ></script> <a href="http://www.authorize.net/" id="AuthorizeNetText" target="_blank">Secure Online Payments</a> </div> 

        
        </ul>
      </div>
      <div class="float_L pc_solution_Cntr"> <span class="Quick_resolution">We Support</span>
        <ul class="quick_ul_li_cntr">
         <li> <a href="#">Support For Antivirus</a></li>
          <li><a href="#">Support For Antivirus Update </a></li>
          <li><a href="#">Laptop Software Support</a></li>
           <li><a href="#">Support For Printer</a></li>
           <li><a href="#">Data Recovery</a></li>
        </ul>
      </div>
      <div class="float_L pc_solution_Cntr"> <span class="Quick_resolution"></span>
        <ul class="quick_ul_li_cntr">
         
         
         
          <li><a href="#">Printers Driver Update</a></li>
          <li><a href="#">Browser Support</a></li>
          <li><a href="#">Operating System Support</a></li>
          <li><a href="#">PC Tune Up </a></li>
          <li><a href="#">PC Optimization</a></li>
          
         
          
         </ul>
      </div>
      <div class="float_L pc_solution_Cntr"> <span class="Quick_resolution">Important Links</span>

        <ul class="quick_ul_li_cntr">
          
        <li><a href="index-2.php" title="Home">Home</a></li>
        <li><a href="about_us.php" title="About Us">About us</a></li>
        <li><a href="privacy_policy.php" title="Privacy POlicy">Privacy Policy</a></li>
        <li><a href="refund_policy.php" title="Refund Policy">Refund Policy</a></li>
        <li><a href="terms_of_use.php" title="Terms of Use">Terms of Use</a></li>
       
        <li><a href="contact_us.php" title="Contact Us">Contact us</a></li>
        </ul>
      </div>
    </div>
   
      
      
      
     
      
      
  </div>
  <!--strt_Page_Bottom_MainContr-->
</div>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-69752099-1', 'auto');
  ga('send', 'pageview');

</script>

<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="http://www.googleadservices.com/pagead/conversion/951392627/?label=Yy2UCJSfrVsQ87LUxQM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>

<!--Start of Tawk.to Script-->
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/563d9414b2ea3bb02546b27e/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<!--End of Tawk.to Script-->
 </body>

<!-- Mirrored from Comptek Solution .com/contact_us by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 24 Sep 2015 09:42:53 GMT -->
</html>