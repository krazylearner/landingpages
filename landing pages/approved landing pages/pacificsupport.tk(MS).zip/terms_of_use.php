<?php include 'recorder.php';?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<!-- Mirrored from Comptek Solution .com/terms_of_use by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 24 Sep 2015 09:42:53 GMT -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Comptek Solution</title>
<link type="text/css" rel="stylesheet" href="css/main.css" media="screen"/>
<link rel="stylesheet" href="menu.css" type="text/css" media="screen" />
<script type="text/javascript" src="js/jquery.js"></script>

<!--End Navigation JavaScript Tag-->
<script type="text/javascript">
        jQuery(window).scroll(function () {
            var topmargin = 400;
                if (jQuery(window).scrollTop() > topmargin) {
                jQuery('#tfnaction').animate({ 'top': '-90px' }, 600);
            } else if (jQuery(window).scrollTop() < (topmargin - 20)) {
                jQuery('#tfnaction').stop(true).animate({ 'top': '96px' }, 500);
            }
        });
    </script>
</head>
<body>
<div id="header">
  <div class="header_outer_cntr">
    <div class="logoCntr float_L"> <a href="index-2.php" title="Welcome to Comptek Solution">
      <h3>Comptek Solution</h3>
      </a> </div>
    <div class="nav_cntr_outer float_L">
      <ul id="nav">
        <li><a href="index-2.php">Home</a></li>
<li><a href="about_us.php" title="About Us">About us </a></li>
        <li><a href="#" title="services">Services</a>
           <ul>   
            <li><a>Support For Antivirus</a></li>
            <li><a>Support For PC</a></li>
            <li><a>Support For Browsers</a></li>
            <li><a>Support For Printers</a></li>
            <li><a>Support For Virus Definations</a></li>
          </ul>
        </li>
        <li><a href="client_testimonial.php" title="Testimonials">Clients testimonial</a></li>
        <li><a href="plan.php" title="Plans">Plan</a></li>
        <li><a href="contact_us.php" title="Contact Us">Contact us</a></li>
      </ul>
    </div>
    <div class="Flag_contr"><img src="pics/flage.png" alt="flags"  class="float_R"/> </div>
  </div>
</div>
<div class="wrapper">
<div class="tfnBox" id="tfnaction">
        <div class="centerCntr">
             <strong>Call for Expert Tech Support</strong>
        <span class="tfn_text">1-844-441-3440</span></div>
</div>
<br><br><br>
    <div class="banner_btm_cntr">
      </div>
  
  
  <div class="Page_Maincontr">
    
        
<br>
<p><strong>Disclaimer:</strong> Comptek Solution .com is an independent online technical support service provider company for third party products, brands and services. The brand names, images, trademarks, products and services of third parties mentioned on this website are only for referential purposes only and Comptek Solution .com has no affiliation with any of these third-party companies unless such relationship is expressed specifically. The services we offer is also available on the website of the brand owners.

  
       </div></p> <br>

<h3 class="heading">Terms & Condition</h3> <br>

<p> THE FOLLOWING TERMS AND CONDITION (THE “TERMS”) CONSTITUTE A LEGAL AND ENFORCEABLE CONTRACT BETWEEN Comptek Solution AND YOU FOR USE OF SUPPORT SERVICES (THE “SERVICES”) YOU SELECTED OR INITIATED ON THE Comptek Solution WEBSITE OR PURCHASED THROUGH A VENDOR. THE POLICY AND MATERIALS SPECIFICALLY REFERRED TO IN THE TERMS ARE INCORPORATED INTO THE TERMS BY REFERENCE. BEFORE YOU CLICK ON THE “I ACCEPT” OR “AGREE” BUTTON, OR OTHERWISE INDICATE ASSENT FOR CONTINUING TO USE THE SERVICES, PLEASE READ THE TERMS BELOW CAREFULLY.</p> <br>

<p> THESE TERMS STATE IMPORTANT REQUIREMENTS REGARDING YOUR USE OF Comptek Solution’S WEBSITE AND Comptek Solution’S COMPUTER SUPPORT SERVICE AND YOUR RELATIONSHIP WITH Comptek Solution. YOU SHOULD READ THEM CAREFULLY AS THEY CONTAIN IMPORTANT INFORMATION AND INSTRUCTIONS SUCH AS HOW LONG IT LASTS, FEES FOR EARLY TERMINATION, OUR RIGHTS TO CHANGE ITS CONDITIONS, LIMITATIONS OF LIABILITY, PRIVACY, AND SETTLEMENT OF DISPUTES BY ARBITRATION INSTEAD OF IN COURT. IF YOU ACCEPT THIS AGREEMENT, IT WILL APPLY TO ALL YOUR SERVICE PLANS FROM US, INCLUDING ALL YOUR EXISTING PLANS. YOUR ACCEPTANCE OF THESE TERMS & CONDITIONS WILL BE IMPLIED BY THE USE OF THE Comptek Solution WEBSITE AND SERVICES.<p> <br>

<p> IF YOU DO NOT AGREE TO THE TERMS, THEN Comptek Solution IS UNWILLING TO PROVIDE THE SERVICES TO YOU. IN THIS CASE YOU SHOULD: (1) CLICK THE “CANCEL” OR OTHER SIMILAR BUTTON, OR OTHERWISE INDICATE REFUSAL; AND (2) NOT USE THE SERVICES AND SEEK A REFUND DURING THE 15 DAY REDEMPTION PERIOD AS INDICATED BELOW.</p> <br>

<p>IMPORTANT NOTICE: LIMITED REDEMPTION PERIOD AND REFUND RIGHTS: THE RIGHT TO A REFUND FOR “ PER INCIDENT PLAN ” WILL EXPIRE WITH IN ONE(1) CALENDAR DAY (“REDEMPTION PERIOD”) FROM THE DATE OF PURCHASE OF THE SINGLE INCIDENT SERVICE PLAN. IN THE EVENT YOU CAN DEMONSTRATE THAT Comptek Solution HAS NOT PROVIDED THE SINGLE INCIDENT SERVICE TO YOUR SATISFACTION, Comptek Solution WILL REFUND YOU THE MONEY YOU PAID FOR THE SERVICES, (LESS SHIPPING, HANDLING AND ANY APPLICABLE TAXES, EXCEPT IN CERTAIN STATES AND COUNTRIES WHERE SHIPPING, HANDLING AND TAXES ARE REFUNDABLE) PROVIDED THAT YOUR REFUND REQUEST IS RECEIVED BY Comptek Solution OR OUR CUSTOMER SERVICE DURING THE REDEMPTION PERIOD, USING THE CONTACT DETAILS DESCRIBED IN SECTION 8 OF THE TERMS.</p> <br>

<p> IF YOU HAVE PURCHASED SUBSCRIPTION SERVICES, YOU MAY CHOOSE TO CANCEL SUCH SUBSCRIPTION SERVICES AND Comptek Solution WILL REFUND YOU THE MONEY PAID FOR THE SUBSCRIPTION SERVICES, (LESS SHIPPING, HANDLING AND ANY APPLICABLE TAXES, EXCEPT IN CERTAIN STATES AND COUNTRIES WHERE SHIPPING, HANDLING AND TAXES ARE REFUNDABLE) PROVIDED YOU HAVE NOT AVAILED ANY SUPPORT SERVICE ON YOUR PC OR OTHER DEVICES AND THAT YOUR REFUND REQUEST IS RECEIVED BY Comptek Solution CUSTOMER SERVICE WITHIN FIVE (5) DAYS FROM THE DATE OF PURCHASE OF SUCH SUBSCRIPTION SERVICE. NOTE: SOME STATES AND JURISDICTIONS DO NOT ALLOW FOR THE LIMITATION OF REFUND RIGHTS AS DESCRIBED IN THIS CLAUSE SO THIS CLAUSE MAY NOT APPLY TO YOU. FURTHERMORE THIS CLAUSE DOES NOT AFFECT ANY OTHER APPLICABLE REFUND RIGHTS. BY CLICKING ON THE “I ACCEPT” OR “I AGREE” BUTTON, OR BY YOUR USE OF THE SERVICES, YOU ARE DEEMED TO HAVE ACCEPTED AND CONSENTED TO BE BOUND BY THE TERMS.</p> <br>

<p> DEFINITIONS: Certain terms defined in these Terms and Condition are also used in the Privacy Policy and are incorporated by reference to these Terms and Condition.<p> <br>

<p> Content: Software, Materials, Services and other related information are collectively referred to as “Content.”</p> <br>

<p> “You” or “you”: “You” means you individually, any person, including any employer that you are acting on behalf of.</p> <br>

<p> “Comptek Solution”: All references to Comptek Solution write to The Best PC Tech Inc, PO Box 1092 Arlington Heights IL 6000-1092</p> <br>

<p> “Comptek Solution Certified Technicians”: “Comptek Solution Certified Technician means” technicians and specialists certified by Comptek Solution to perform the Services under this Agreement.</p> <br>

<p> “Per-Incident-Services”: “Per Incident Plans” or “Incident Plans” or “Single Incident Service” are non-tenured service provided by Comptek Solution with the sole objective of fixing a single and specific technical problem faced by You”.</p> <br>

<p>“Subscription-Based-Services”: “Subscription Based Services” or “Subscription Services” are tenured Subscription plans offered by Comptek Solution that are active for a specified period and will not include any incident based plans such as “Per Incident Plan” or the like.</p> <br>

<p>“Services”: Services are Per-Incident-Services or Subscription-Based-Services provided by Comptek Solution to You.</p> <br>

<p>“Comptek Solution Website”: Comptek Solution Websites includes www.thebbestpccare.com and or any other Comptek Solution owned, operated, licensed or controlled website or any other website owned, operated, licensed or controlled by reseller of THE BEST PC TECH INC services.</p> <br>

<p>“Services”: All references to “Services” refer to any Comptek Solution service delivered by Comptek Solution Certified Technicians, under the plan that you enter into with Comptek Solution through use of the Comptek Solution Websites or by calling the Comptek Solution phone number mentioned on the Comptek Solution Websites. These Terms of Use govern all plans available through the Comptek Solution Website.</p> <br>

<p>“Materials”: “Materials” means any web casts, download areas, white papers, press releases, datasheets, FAQs, product information, quick reference guides, or other works of any kind that are made available to download from the Comptek Solution Websites are the proprietary and copyrighted work of Comptek Solution and/or its suppliers. The definition of “Materials” does not include the design or layout of the Comptek Solution Websites or any other Comptek Solution owned, operated, licensed or controlled website.</p> <br>

<p>“Software”: “Software” means a computer program of any kind, whether owned by Comptek Solution or a third party, whether delivered via download, CD, other media, or other delivery method, including client and/or network security software. Elements of the Software are protected under copyright, trade secret, unfair competition, and other laws. Software includes both Comptek Solution Software and third party Software. Your use of Software is subject to the respective agreements such as a license agreement or user agreement that accompanies or is included with the Software, ordering documents, exhibits, and other </p> <br>

<p>Services </p> <br>
<p>1.1 Service Overview </p> <br>

<p>(1) Introduction. Services may include Per-Incident-Services that are available on a single incident basis, for a fee ; or Subscription-Based- Services, which are an entitlement to more than one Service over a period of time . Comptek Solution shall provide the Services as set forth in the Terms and Conditions. Comptek Solution’s service representative, as its discretion, will attempt to provide to You the Services over the telephone, through a live chat session on Your personal computer, remotely over the internet, or by email or in person. Comptek Solution continually strives to improve the usability and performance of its products and services. In order to optimize the Services, and solely to the extent permitted by applicable law, Comptek Solution may, at its discretion, modify the features or descriptions of the Services from time to time; however this shall not adversely affect the quality of any specific Services which Comptek Solution has already expressly agreed to provide to You.</p> <br>

<p>(2) Support Software Tool and Remote Access. During the Services session, Comptek Solution may (i) ask You to install certain support software on Your personal computer by downloading the support software from the Site and/or (ii) ask for Your permission to use the remote assist tool through the Comptek Solution service representative to enable Comptek Solution to remotely access and take control of Your personal computer; and/or (iii) gather system data and modify computer settings in order to diagnose or repair a problem; (iv) utilize certain third party support software on Your personal computer, which will be removed upon the completion of the Services session. The support software (including any third party support software) and remote assist tool are owned by Comptek Solution or applicable third party licensors and suppliers and may be collectively referred to as the “Support Software Tool” in the Terms and Conditions. The Support Software Tool will be used to analyze, diagnose, resolve more difficult problems and/or provide system optimization functions. By electing to receive support, You agree to allow Comptek Solution to use whatever Support Software Tools are deemed necessary to repair Your personal computer, including remote access.</p> <br>

<p>You understand that if remote access is used on Your computer there will be no residual software from the remote session; You also understand that you have the ability to disconnect the remote access anytime during the remote access session; You understand that at the end of the remote access session there may be a text or an xml or a flash file placed on your computer that will explain the work that was done on your computer and/or provide information for contacting Comptek Solution for further assistance in future. If such a file is placed on your computer, you have the option to either save the file or to delete it from your computer.</p> <br>

<p>Comptek Solution may, but has no obligation to, monitor and record the Services, including telephone calls and online sessions for purposes of improving customer service, internal training and internal market research. You hereby grant permission to Comptek Solution to monitor and record the Services and to use or disclose any information as necessary or appropriate to satisfy any law, regulation or other governmental request; to provide the Services to You or other users; to protect ourselves and/or other users and to enhance the types of Services we may provide to You in the future. You also grant Comptek Solution permission to combine Your information with that of others in a way that does not identify You or any individual personally to improve the Services, for training, for marketing and promotional purposes, and for other business purposes.</p> <br>

<p>(3) Description of Services.</p> <br>

<p> Comptek Solution shall provide the following Services if applicable and subject to the Terms and Conditions. Comptek Solution’s service representative diagnoses PC to determine if it is infected by spyware or virus, and removes the spyware or virus found in Your personal computer: Comptek Solution’s service representative will help customers install and set-up certain software products. Comptek Solution’s service representative will help customers improve PC performance. Comptek Solution’s service representative will help customers install, set up antivirus software applications, and improve PC Performance. Comptek Solution’s service representative will analyze the results of the diagnosis and suggest appropriate service offerings to solve any problems found . Additionally the representative will tune up key operating system settings to endeavor to improve PC performance. Comptek Solution’s service representative will help customers diagnose and address PC, network and connected peripheral and device related issues Other services which may be provided by Comptek Solution.</p> <br>

<p>Your Responsibilities</p> <br>
<p>2.1 Basic Responsibilities.</p> <br>

<p>You agree that You are a legal license holder of the software on Your personal computer and Your use of the Services and the internet is solely at Your own risk. By electing to receive the Services, You confirm that You (a) have full access to Your hardware and software that are the basis of the problem, and (b) have completed a back-up onto separate media of any software or data on the hardware that may be impacted by the Services. All information that You provide to Comptek Solution must be accurate, including Your name and address, and if applicable, any credit or charge card numbers, expiration dates or any other payment information provided by you to Comptek Solution. You further represent that You authorize Comptek Solution to bill the credit card that You provide to Comptek Solution, for any charges to which you consent.</p> <br>

<p>2.2 Liability Release.</p> <br>

<p>To the extent permitted by applicable law, Comptek Solution will have no liability for loss of or recovery of data, programs, or loss of use of systems(s) or networks arising out of the Services or any act or omission, including negligence, by Comptek Solution and/or its representatives. If Comptek Solution works with You on any password or other access control oriented problems, Comptek Solution strongly recommends that You reset such passwords(s) immediately following the completion of the Services.</p> <br>

<p>2.3 Transfer</p> <br>

<p>The Subscription-Based-Services are only transferable once during the subscription period from one computer to another, provided it is owned by you. You may not use the Services in connection with a service bureau or any other distributing or sharing arrangement, on behalf of any third parties or with respect to any hardware or software not personally owned by You.</p> <br>

<p>2.4 Data Backup</p> <br>

<p>Comptek Solution does not provide data backup or restoration services. You are solely responsible for maintaining and backing up all information, data, text or other materials (collectively “customer data”) and software stored on your computer and storage media before ordering the services. You acknowledge and agree that Comptek Solution or its referral partners have no responsibility or liability under any circumstance at any time for any loss or corruption of customer data, software or hardware that may arise out of the services. Comptek Solution does not provide backup copies or support installation of unlicensed software to customers. Please ensure that you have a licensed copy of all necessary software.</p> <br>

<p>Service Plans; Refunds; Billing; Payment Renewals</p> <br>
<p>3.1 Per-Incident-Services.</p> <br>

<p>The Per-Incident-Services shall be provided for on a one time basis. The term “one time” means that the service will address a single issue or problem for a customer on Your personal computer and include follow-up consultation upon request within seven (7) days on the same issue or problem. The Services may not be successful because the problem may be beyond Our ability to resolve remotely. If You have purchased a Single Incident Service from Comptek Solution, then the following warranty applies: if We are not able to answer Your question or resolve Your technology problem and You have complied with all of Your obligations in these Terms, We will not charge You a fee for the One Time Service. If You experience a problem with the resolution We provided and You call Us within seven (7) days from the day You originally received the Single Incident Service, We will use commercially reasonable efforts to try to resolve Your problem at no additional charge. If those efforts are unsuccessful, We will refund the fees that You paid for the Individual Service. As set forth below, there are no other warranties for the Services.</p> <br>

<p>3.2 Subscription Services.</p> <br>

<p>For Subscription Services, the applicable fees will depend on the type of subscription that You purchase, and the duration of the subscription. Unless you have purchased a special or trial offer Subscription Service that specifically provides otherwise, a one time set up fee applies to all Subscription Services.</p> <br>

<p>3.3 Exclusion from Services</p> <br>

<p>Service Plans; Refunds; Billing; Payment Renewals</p> <br>
<p>3.1 Per-Incident-Services.</p> <br>

<p>The Per-Incident-Services shall be provided for on a one time basis. The term “one time” means that the service will address a single issue or problem for a customer on Your personal computer and include follow-up consultation upon request within seven (7) days on the same issue or problem. The Services may not be successful because the problem may be beyond Our ability to resolve remotely. If You have purchased a Single Incident Service from Comptek Solution, then the following warranty applies: if We are not able to answer Your question or resolve Your technology problem and You have complied with all of Your obligations in these Terms, We will not charge You a fee for the One Time Service. If You experience a problem with the resolution We provided and You call Us within seven (7) days from the day You originally received the Single Incident Service, We will use commercially reasonable efforts to try to resolve Your problem at no additional charge. If those efforts are unsuccessful, We will refund the fees that You paid for the Individual Service. As set forth below, there are no other warranties for the Services.</p> <br>

<p>3.2 Subscription Services.</p> <br>

<p>For Subscription Services, the applicable fees will depend on the type of subscription that You purchase, and the duration of the subscription. Unless you have purchased a special or trial offer Subscription Service that specifically provides otherwise, a one time set up fee applies to all Subscription Services.</p> <br>

<p>3.3 Exclusion from Services</p> <br>

<p>“Services shall not include the following:</p> <br>

<p>Any item or activity not covered by the terms of a PerIncident-Service or Subscription-Based-Services;</p> <br>
<p>Service beyond the duration limitations identified in your Service plan;</p> <br>
<p>Problem diagnosis and support that may not be completed because of a problem with your computer or other equipment, or their configuration that is beyond our control;</p> <br>
<p>Software, including the operating system and software added to the registered hardware products which are out of scope for the Service Plan;
Problems that may and do result from:</p> <br>
<p>a) External causes such as accident, abuse, misuse, or problems with electrical power;</p> <br>
<p>b) Usage that is not in accordance with product instructions provided by manufacture;</p> <br>
<p>c) Failure to follow the product instructions provided by manufacture or failure to perform preventive maintenance; or</p> <br>
<p>d) Problems caused by using accessories, parts, or components not compatible with the product.</p> <br>
<p>e) Non Compliance with the Comptek Solution technician instructions for resolving the query.</p> <br>
<p>f) Malfunction of hardware such as printer, power-supply, memory, processor, monitor or any other such hardware components</p> <br>

<p>3.4 Refund.</p> <br>

<p>Any refund will be limited to the amount paid by You.</p> <br>

<p>3.5 Payment for the Services.</p> <br>

<p>The applicable fees for the Services You order may be quoted on the telephone and/or may be available on the Site. The fee for the Services will be charged directly on Your credit card and You agree to pay the charges applicable to Your selected Services, as well as any applicable taxes. For purchases of the Services made by You from Comptek Solution through the Site: (1) You agree that Comptek Solution may charge to Your credit card or other valid payment mechanism requested by You and approved b y Comptek Solution all amounts due and owing for Comptek Solution for the Services; (2) Unless otherwise agreed b y Comptek Solution in writing, all payments for the Services must be made at the time of purchase prior to receiving any services from Comptek Solution; (3) You agree that Comptek Solution may collect interest at the lesser of 1.5 % per month or the highest amount permitted by law on any amounts not paid when due; (4) You agree that Comptek Solution is under no obligation to pay to render Services if the payment for services as required are not made. Purchases of the Services made by You from a Reseller/Vendor will be subject to terms of sale of the Reseller/Vendor.</p> <br>

<p>3.6 Credit Card Billing</p> <br>

<p>You may be asked to provide Comptek Solution with a credit card number from a card issuer that we accept in order to activate your Service. You hereby authorize Comptek Solution to charge and/or place a hold on your credit card with respect to any unpaid charges for Services or any related equipment. You authorize the issuer of the credit card to pay any amounts described herein without requiring a signed receipt, and you agree that these charges are to be accepted as authorization to the issuer of the credit card to pay any amounts described herein without requiring a signed receipt, and you agree that these charges are to be accepted as authorization to the issuer of the credit card to pay all such amounts. You authorize Comptek Solution and/or any other company who bills products or services, or acts as billing agent for Comptek Solution to continue to attempt to charge and/or place holds with respect to all sums described herein, or any portion thereof, to your credit card until such amounts are paid in full. You agree to provide Comptek Solution with updated credit card information upon Comptek Solution’S request and any time the information you previously provided is no longer valid. You acknowledge and agree that neither Comptek Solution nor any Comptek Solution affiliated company will have any liability whatsoever for any nonsufficient funds or other charges incurred by you as a result of such attempts to charge, and/or place holds on, your credit card. If you mistakenly provide a debit card number, instead of a credit card number, you authorize all charges described herein to be applied to such debit card unless and until you provide a credit card number. In the event you are enrolled, or later enroll, in an automatic payment or electronic funds transfer plan, you agree that all sums described herein may be charged, at Comptek Solution’S option, to the account number provided for such automatic payment or electronic funds transfer plan. When payment is made by credit card or debit card, payment will also be subject to the terms and conditions established by the credit or debit card issuer.</p> <br>

<p>3.7 Renewal Policy</p> <br>

<p>By authorizing Comptek Solution to charge Your credit card for Your Subscription Service, You further authorize Comptek Solution to continue to charge Your credit card (or a replacement card, if the credit issuing entity informs Comptek Solution that a replacement card has been issued) for all fees associated with a Recurring Subscription Service, including renewals. You must contact Comptek Solution if You do not wish to renew Your Recurring Subscription Service; if You do not contact Comptek Solution, the Rec ur r ing Subscription Service that You selected will automatically renew for the same subscription duration that You initially selected, at Comptek Solution’s then-applicable fees. A subscription under the 1-year or 2-year or 3-year Annual Maintenance Plan does not automatically renew and ends at the end of the applicable period</p> <br>

<p>3.8 Fair Usage Policy & Termination</p> <br>

<p>Though Comptek Solution has no limits on the amount of online support requests a Subscription based plan user may make during the subscription period, however, each Subscriber’s use of the support services for the subscription based plans are subject to Comptek Solution’S “fair use” policy. Under this policy, if at any time, in Comptek Solution’S sole discretion, a subscription based plan user is found to be abusing the service by exceeding the level of use reasonably expected from someone using a Subscription based Plan for individual use, then Comptek Solution reserves the right to suspend or terminate Subscriber’s Subscription Services. In addition, Comptek Solution reserves the right to suspend or terminate any Subscription Services of any Subscriber that Comptek Solution, in its sole discretion, determines are being used (a) fraudulently, (b) by any person other than Subscriber, or (c) for any computer system other than a Registered System. User may terminate the Service at any time by giving written or electronic notice to Comptek Solution; provided, however, that User will not be entitled to a refund of any fees prepaid by User for the Service.</p> <br>

<p>Privacy & Data Protection</p> <br>
<p>When You visit the Site, the Comptek Solution Privacy Policy that is available for review via the “Privacy Policy” link that appears on the Site shall apply. If you have not yet reviewed the Comptek Solution Privacy Policy, then please do so prior to agreeing to these Terms and Conditions. You agree that beyond the Personal Information identified in the Privacy Policy, any information or data disclosed or sent to Comptek Solution over the telephone, electronically or otherwise, is not confidential or proprietary to you. When You request the Services, the following information will be collected and sent from Your personal computer to Comptek Solution via an Internet connection:</p> <br>

<p>The information provided by You to Comptek Solution’s service representative over the phone or entered by You into Comptek Solution’s online interface when requesting the Services; and The type and version of operating system and Internet browser used by Your personal computer. During Your Services session, if a Support Software Tool is installed, the following information may be collected from your computer by the Support Software Tool and sent to Comptek Solution via secured connection:</p> <br>

<p>The number of files scanned, threats found, and threats fixed by the Support Software Tool; The type of threats found;</p> <br>

<p>The number and type of threats remaining that have not been fixed by the Support Software Tool; Whether a firewall is active;</p> <br>

<p>Whether antivirus software is installed, running, and up to date; Browser information including security and temporary file settings; System information related to the operating system, memory and disk space, proxy configuration and directory listings for the Support Software Tool; The security status (good/fair/poor) of the computer as determined by the Support Software Tool; Installed programs and active processes information; and Application log file information and registry data.</p> <br>

<p>Also at Comptek Solution’s discretion, depending on type of the technical support issue, Comptek Solution may choose to collect additional information. All of the collected in formation is necessary for the purpose delivery of the Services including analyzing, diagnosing, resolving the problem You have encountered, and optimizing the functionality of Comptek Solution’s products and services. The information may be transferred to the Comptek Solution group in the United States or other countries that may have less protective data protection laws than the region in which You are situated (including the European Union), but Comptek Solution has taken steps so that the collected information, if transferred, receives an adequate level of protection.</p> <br>

<p>Comptek Solution may disclose the collected information if asked to do so by a law enforcement official as required or permitted by law or in response to a subpoena or other legal process. In order to promote awareness, detection and prevention of Internet security risks, Comptek Solution may share certain information with research organizations and other security software vendors. Comptek Solution may also use statistics derived from the information to track and publish reports on security risk trends.</p> <br>

<p>Unlawful and Non-Commercial Use Limitation</p> <br>
<p>5.1. Personal and Non-Commercial Use Limitation</p> <br>

<p>Unless otherwise specified, the Services, Materials and Software are solely for your personal and noncommercial use in addressing matters covered by your Service Plan. You may not modify, copy, distribute, transmit, display, perform, reproduce, publish, license, modify, create derivative works from, transfer, distribute or sell any information, software, products or services obtained from the Services, Materials, or Software. Any Services, Materials, and Software are available only in connection with Services under a valid Service Plan.</p> <br>

<p>5.2 Unlawful or Prohibited Use</p> <br>

<p>As a condition of your use of the Comptek Solution Websites or any Services, you will not use the Materials, Software or Services for any purpose that is unlawful or prohibited by these Terms of Use. You may not use the Services, Materials, or Software in any manner that could damage, disable, overburden, or impair any Comptek Solution server, or the network(s) connected to any Comptek Solution server, or interfere with any other party’s use and enjoyment of any of the Comptek Solution Portal, the Materials, Software or Services. You may not attempt to gain unauthorized access to any Comptek Solution Websites, the Materials, Software or Services, other accounts, computer systems or networks connected to any Comptek Solution server or to any of the Comptek Solution Websites, the Materials, Software or Services, through hacking, password mining or any other means. You may not obtain or attempt to obtain any Comptek Solution Websites, the Materials, Software or Services or information through any means other than that specifically permitted to you under a Plan Order.</p> <br>

<p>5.3 General Usage Restrictions</p> <br>

<p>Any other use of the Comptek Solution Websites Services, Materials or Software, other than as explicitly permitted by Comptek Solution is prohibited. Rights to execute, copy, modify, display, transmit, distribute, manufacture, use, sale are all reserved to Comptek Solution and its suppliers. Reverse engineering and decompilation of the Software is strictly prohibited.</p> <br>

<p>Other Important Information</p> <br>
<p>6.1 Disclaimer of Warranty</p> <br>

<p>TO THE EXTENT PERMITTED BY APPLICABLE LAW, Comptek Solution EXPRESSLY DISCLAIMS ALL WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY WARRANTY OF MERCHANTABILITY, FITNESS FOR A PA RTICULA R PURPOSE OR NONINFRINGEMENT . TO THE EXTENT PERMITTED BY APPLICABLE LAW, Comptek Solution MAKES NO WARRANTIES THAT: (I) THE SERVICES AND/OR SITE WILL MEET YOUR REQUIREMEN TS; (II) THE SERVICES AND/OR SITE WILL BE UNINTERRUPTED, TIMELY, SECURE, OR ERROR-FREE; (III) THE RESULTS THAT MAY BE OBTAINED FROM THE USE OF THE SERVICES AND/OR SITE WILL BE ACCURATE OR RELIABLE; (IV) THE QUALITY OF ANY SERVICES, PRODUCTS, SERVICES OR INFORMATION PURCHASED OR OBTAINED BY YOU THROUGH THE SERVICES AND/OR SITE WILL MEET YOUR EXPECTATIONS; AND (V) ANY ERRORS IN THE SERVICES AN D/OR SITE WILL BE CORRECTED. ANY SUPPORT SOFTWARE TOOL, MATERIALS AND/OR DATA DOWNLOADED OR OTHERSWISE OBTAINED BY YOU THROUGH THE USE OF THE SERVICES IS AT YOUR OWN DISCRETION AND RISK. THE SUPPORT SOFTWARE TOOL IS PROVIDED “AS IS,” EXCLUSIVE OF ANY WARRANTY AND PROVIDED IN ACCORDANCE WITH THE SUPPORT SOFTWARE TOOL USAGE AGREEMENT. Comptek Solution DOES NOT WARRANT THIRD PARTY PRODUCTS.</p> <br>

<p>6.2 Limitation of Liability.</p> <br>

<p>SOME STATES AND JURISDICTIONS INCLUDING MEMBER COUNTRIES OF THE EUROPEAN ECONOMIC AREA, DO NOT ALLOW FOR THE LIMITATION OR EXCLUSION OF LIABILITY FOR INCIDENTAL OR CONSEQUENTIAL DAMAGES SO THE BELOW LIMITATION OR EXCLUSION MAY NOT APPLY TO YOU. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW AND REGARD LESS OF WHETHER ANY REMEDY SET FORTH HEREIN FAILS OF ITS ESSENTIAL PURPOSE, IN NO EVENT WILL Comptek Solution BE LIABLE TO YOU FOR ANY SPECIAL , CONSEQUENTIAL , INDIRECT OR SIMILAR DAMAGES, INCLUDING ANY LOST PROFITS OR LOST DATA ARISING OUT OF THE PROVISION OF SERVICES EVEN IF Comptek Solution HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. IN NO CASE SHALL Comptek Solution’S LIABILITY EXCEED THE GREATER OF THE PRICE YOU PAID FOR THE SERVICES OR FIFTY DOLLARS (U.S. $50.00) OR EQUIVALENT AMOUNT IN THE APPLICABLE CURRENCY.</p> <br>

<p>6.3 Limitation of Actions</p> <br>

<p>Any cause of action by you must be commenced within three months after the cause of action arose or it shall be forever waived and barred.</p> <br>

<p>6.4 Indemnity</p> <br>

<p>You agree to indemnify, defend, and hold Comptek Solution, its subsidiaries, affiliates, officers, directors, employees, agents, licensors, consultants, suppliers, and any third-party Web site providers harmless from and against all claims, demands, actions, liabilities, losses, expenses, damages, and costs, including actual attorneys’ fees, resulting from your violation of the material terms of these Terms of Use, any misuse or abuse of a Service, any use of the Service that amounts to infringement, or infringement by any other user of your account of any intellectual property or other right of Comptek Solution or any other third party. You will cooperate as fully as reasonably required in Comptek Solution’S defense of any claim. Comptek Solution reserves the right, at its own expense, to assume the exclusive defense and control of any matter otherwise subject to indemnification by you and you shall not in any event settle matter without the written consent of Comptek Solution. You agree immediately to notify Comptek Solution of any unauthorized use of your account or any other breach of security known to you.</p> <br>

<p>6.5 Proprietary Rights.</p> <br>

<p>Comptek Solution or its licensors or suppliers retains ownership of all proprietary rights in the Services, the Comptek Solution Web site, the Support Software Tool, and in all trade names, trademarks and service marks associated or displayed with the Services. You will not remove, deface or obscure an y of Comptek Solution’s copyright or trademark notices and/or legends or other proprietary notices on, incorporated therein, or associated with the Services. You may not reverse engineer, reverse compile or otherwise reduce to human readable form any Support Software Tool with the Services.</p> <br>

<p>6.6 Force Majeure.</p> <br>

<p>Comptek Solution shall not be responsible for any failure to perform due to unforeseen circumstances or to causes beyond Comptek Solution’s reasonable control, including but not limited to acts of God, war, riot, embargoes, acts o f civil or military authorities, fire, floods, accidents, strikes, lockouts, or shortages of transportation, facilities, a large scale outbreak of a new computer virus, fuel, energy, labor or materials. You hereby release Comptek Solution from any and all liability, and agree that Comptek Solution shall not be liable to you or any third party for any direct or indirect damages whatsoever, resulting from such delays.</p> <br>

<p>Comptek Solution or its suppliers may, at any time, without notice or liability, restrict the use of the Service or limit its time of availability in order to perform maintenance activities and to maintain session control.</p> <br>

<p>6.7 Export Regulation.</p> <br>

<p>You acknowledge that the Services, Support Software Tool and related technical data and services (collectively “Controlled Technology”) may be subject to the import and export laws of the United States, specifically the U.S. Export Administration Regulations (EAR), and the laws of any country where Controlled Technology is imported or re-exported. You agree to comply with all relevant laws and will not export any Controlled Technology in contravention to U.S. law nor to any prohibited country, entity, or person for which an export license or other governmental approval is required. All Comptek Solution product is prohibited for export or re-export to Cuba, North Korea, Iran, Syria and Sudan and to any country subject to relevant trade sanctions. You hereby agree that You will not export or sell any Controlled Technology for use in connection with chemical, biological, or nuclear weapons, or missiles, drones or space launch vehicles capable of delivering such weapons.</p> <br>

<p>6.8 SEVERABILITY & WAIVER</p> <br>

<p>If any provision of the Terms of Service be held invalid or unenforceable, that portion shall be enforced to the maximum extent possible, and all other provisions contained in the Terms of Service shall remain in full force and effect. Comptek Solution’s failure to enforce any provision of the Terms of Service shall not be deemed a waiver of such provision nor of the right to enforce such provision.</p> <br>

<p>6.9 Modifications</p> <br>

<p>Comptek Solution reserves the right to amend the Terms and Condition, and the Comptek Solution Portal at any time by (a) posting a revised version of the Terms and Conditions on the Comptek Solution Portal or by (b) sending information regarding any amendment to the Terms of Service to the email address you provide to Comptek Solution in connection with registration. You are responsible for regularly reviewing the Comptek Solution website to be notified of any amendments to the Terms and Conditions.</p> <br>

<p>Third Party Products and Services</p> <br>
<p>7.1 Third Party Products</p> <br>

<p>As part of the Services, Comptek Solution may suggest that you acquire, install and use certain third party software or services (“Third Party Software”). Third Party Software is licensed to you by the respective owners or licensees of the Third Party Software. You must agree to the terms and conditions set forth by such owners or licensees before installing Third Party Software, whether Comptek Solution assists you in the acquisition, installation, and/or use of Third Party Software. Comptek Solution has no responsibility or rights to the Third Party Software and does not license Third Party Software to you or make any representation or warranty regarding the Third Party Software. To the extent that we provide technical assistance and support for Third Party Software or equipment, you must ensure that you comply with the terms and conditions under which you licensed such Third Party Software or purchased such equipment. We make no representation or warranty that we are an authorized service provider for Third Party Software or for any equipment; it is your sole responsibility to determine if you require additional rights for us to provide such support and if so, to acquire such rights. You acknowledge that support of Third Party Software or equipment by an unauthorized service provider may void any warranty made by the supplier of such Third Party Software or equipment.</p> <br>

<p>7.2 Third Party Services</p> <br>

<p>As part of the Services, Comptek Solution may suggest certain third party services to you. If you choose to subscribe to or otherwise use any third party services, your use of any such services is subject to the terms of service of such third party service provider. You agree to comply with such provider’s terms of service and that the third party provider is solely responsible for delivery of its service(s) to you and your use of them. Third party services include, but are not limited to technical support, portal, training, music, gaming and storage services that Comptek Solution may elect to make available from time to time. Violation of such third party provider’s terms of service may, in Comptek Solution’S sole discretion, result in the termination of your customer account and use of service.</p> <br>

<p>General</p> <br>
<p>The Terms will be governed by the laws of the State of Illinois, United States of America. Notwithstanding the foregoing, nothing in the Terms will derogate from any rights You may have under existing consumer protection legislation or other applicable laws in Your jurisdiction. The Terms are the entire agreement between You and Comptek Solution relating to the Services and : (i) supersede all prior or contemporaneous oral or written communications, proposals, and representations with respect to its subject matter; and (ii) prevail over any conflicting or additional terms of any quote, order, acknowledgment, or similar communications between the parties. The Terms shall terminate immediately upon Your breach of any term contained herein and You shall cease use of the Services. The disclaimers of warranties and damages and limitations on liability set forth in the Terms shall survive termination. Should You have any questions concerning the Terms, or if You desire to contact Comptek Solution for any reason, please write to: (i) The Best PC Tech Inc PO Box 1092 -1092</p> <br>

<p>If user has any questions about the Cancellation Policy at our Website, user can e-mail user inquiries to support@compteksolution.com
</div>

    </div>
  </div>
</div>


<div class="Page_Bottom_MainContr">
  <!--strt_Page_Bottom_MainContr-->
  <div class="Page_Bottom_Contr">
    <div class="image_Gallry_contr">
      <marquee behavior="" scrollamount="4" onmouseover="stop();" onmouseout="start();">
      
      </marquee>
    </div>
    
     
    
     
    
 <div class="FootrNav_Maincontr">
      <div class="float_L pc_solution_Cntr"> <span class="Quick_resolution">Comptek Solution</span>
       
          <h4> Toll Free: 1-844-441-3440</h4>
          <h4>Email: support@compteksolution.com </h4>
          <img src="pics/paypal.png" alt="payment" />
 <!-- (c) 2005, 2015. Authorize.Net is a registered trademark of CyberSource Corporation --> <div class="AuthorizeNetSeal"> <script type="text/javascript" language="javascript">var ANS_customer_id="d1a5e3a4-08ba-4cab-9e74-41c9d1d8a9a1";</script> <script type="text/javascript" language="javascript" src="../verify.authorize.net/anetseal/seal.js" ></script> <a href="http://www.authorize.net/" id="AuthorizeNetText" target="_blank">Secure Online Payments</a> </div> 

        
        </ul>
      </div>
      <div class="float_L pc_solution_Cntr"> <span class="Quick_resolution">We Support</span>
        <ul class="quick_ul_li_cntr">
         <li> <a href="#">Support For Antivirus</a></li>
          <li><a href="#">Support For Antivirus Update </a></li>
          <li><a href="#">Laptop Software Support</a></li>
           <li><a href="#">Support For Printer</a></li>
           <li><a href="#">Data Recovery</a></li>
        </ul>
      </div>
      <div class="float_L pc_solution_Cntr"> <span class="Quick_resolution"></span>
        <ul class="quick_ul_li_cntr">
         
         
         
          <li><a href="#">Printers Driver Update</a></li>
          <li><a href="#">Browser Support</a></li>
          <li><a href="#">Operating System Support</a></li>
          <li><a href="#">PC Tune Up </a></li>
          <li><a href="#">PC Optimization</a></li>
          
         
          
         </ul>
      </div>
       <div class="float_L pc_solution_Cntr"> <span class="Quick_resolution">Important Links</span>

        <ul class="quick_ul_li_cntr">
          
        <li><a href="index-2.php" title="Home">Home</a></li>
        <li><a href="about_us.php" title="About Us">About us</a></li>
        <li><a href="privacy_policy.php" title="Privacy POlicy">Privacy Policy</a></li>
        <li><a href="refund_policy.php" title="Refund Policy">Refund Policy</a></li>
        <li><a href="terms_of_use.php" title="Terms of Use">Terms of Use</a></li>
       
        <li><a href="contact_us.php" title="Contact Us">Contact us</a></li>
        </ul>
      </div>
    </div>
    
      
      

    
      
      
  </div>
  <!--strt_Page_Bottom_MainContr-->
</div>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-69752099-1', 'auto');
  ga('send', 'pageview');

</script>

<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="http://www.googleadservices.com/pagead/conversion/951392627/?label=Yy2UCJSfrVsQ87LUxQM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>


 </body>

<!-- Mirrored from Comptek Solution .com/terms_of_use by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 24 Sep 2015 09:42:53 GMT -->
</html>